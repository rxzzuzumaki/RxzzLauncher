package com.rxzz.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val games = mutableListOf(
        Game("Game Saya", "com.example.mygame"),
        Game("Game 2", "com.example.game2")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(9,10,15))
        }

        val title = TextView(this).apply {
            text = "RXZZ LAUNCHER"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 30)
        }
        root.addView(title)

        games.forEach { game ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(22, 18, 18, 18)
                setBackgroundColor(Color.rgb(25,26,34))
            }

            val name = TextView(this).apply {
                text = game.name
                textSize = 19f
                setTextColor(Color.WHITE)
            }
            card.addView(name, LinearLayout.LayoutParams(0, 80, 1f))

            val play = Button(this).apply {
                text = "PLAY"
                setOnClickListener { launchGame(game.packageName) }
            }
            card.addView(play)

            root.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = 18
            })
        }

        val info = TextView(this).apply {
            text = "Tambahkan game sendiri dengan mengubah daftar games di MainActivity.kt."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 20, 0, 0)
        }
        root.addView(info)

        setContentView(root)
    }

    private fun launchGame(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "Game belum terpasang.", Toast.LENGTH_SHORT).show()
        }
    }

    data class Game(val name: String, val packageName: String)
}
