# Rxzz Launcher

Launcher Android sederhana untuk menjalankan game yang sudah terpasang.

## Build
Buka folder ini di Android Studio, lakukan Gradle Sync, lalu Build > Build APK(s).

## Menambah game
Edit `MainActivity.kt`, lalu tambahkan:
`Game("Nama Game", "package.name.game")`

Versi pertama sengaja sederhana. Fitur import APK, cover game, library, dan pengelolaan game dapat ditambahkan berikutnya.
